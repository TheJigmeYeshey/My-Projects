@extends('layouts.default')

@section('page-content')
<section class="capsule">
<div class='pill'>
        <div class="content-shaper">
            <h3>Add Project: </h3>
            <form method="post" action=' {{url("project/$project->id")}} ' enctype="multipart/form-data">
                {{csrf_field()}}
                {{method_field('PUT')}}
                <table>
                    <tr><td><h3>Title: </h3></td><td><input type="text" name="title" value="{{ $project->title }}"></td></tr>
                    @if ($errors->has('title'))
                        @foreach ($errors->get('title') as $error)
                            <tr><td></td><td><h4>{{ $error }}</h4></td></tr>
                        @endforeach
                    @endif
                    @if ($project->image)
                        <tr>
                            <td><h3>Current Image:</h3></td>
                            <td><img src="{{url($project->image)}}" alt="project image" style="width:300px;height:300px;"></td>
                        </tr>
                    @endif
                    <tr><td><h3>Image (optional): </h3></td><td><input type="file" name="image" value="{{ $project->image }}"></td></tr>
                    @if ($errors->has('image'))
                        @foreach ($errors->get('image') as $error)
                            <tr><td></td><td><h4>{{ $error }}</h4></td></tr>
                        @endforeach
                    @endif
                    @if ($project->pdf)
                        <tr>
                            <td><h3>Current PDF:</h3></td>
                            <td><a href="{{url($project->pdf)}}" download>Download PDF for more information.</a></td>
                        </tr>
                    @endif
                    <tr><td><h3>PDF file (optional): </h3></td><td><input type="file" name="pdf" value="{{ $project->image }}"></td></tr>
                    <tr><td><h3>Industry Partner: </h3></td><td><input type="text" name="industry_partner" value="{{Auth::user()->name}}"></td></tr>
                    @if ($errors->has('industry_partner'))
                        @foreach ($errors->get('industry_partner') as $error)
                            <tr><td></td><td><h4>{{ $error }}</h4></td></tr>
                        @endforeach
                    @endif
                    <tr><td><h3>Email: </h3></td><td><input type="text" name="email" value="{{ Auth::user()->email }}"></td></tr>
                    @if ($errors->has('email'))
                        @foreach ($errors->get('email') as $error)
                            <tr><td></td><td><h4>{{ $error }}</h4></td></tr>
                        @endforeach
                    @endif
                    <tr><td><h3>Description: </h3></td><td><textarea name="description" rows="4">{{ $project->description }}</textarea></td></tr>
                    @if ($errors->has('description'))
                        @foreach ($errors->get('description') as $error)
                            <tr><td></td><td><h4>{{ $error }}</h4></td></tr>
                        @endforeach
                    @endif
                    <tr><td><h3>Students Needed (in numbers): </h3></td><td><input type="number" name="students_needed" value="{{ $project->students_needed }}"></td></tr>
                    @if ($errors->has('students_needed'))
                        @foreach ($errors->get('students_needed') as $error)
                            <tr><td></td><td><h4>{{ $error }}</h4></td></tr>
                        @endforeach
                    @endif
                    <tr><td><h3>Year: </h3></td><td><input type="number" name="year" value="{{ $project->year }}"></td></tr>
                    @if ($errors->has('year'))
                        @foreach ($errors->get('year') as $error)
                            <tr><td></td><td><h4>{{ $error }}</h4></td></tr>
                        @endforeach
                    @endif
                    <tr><td><h3>Trimester: </h3></td><td><select name="trimester">
                        <option value="1" @if($project->trimester == 1) selected @endif>1</option>
                        <option value="2" @if($project->trimester == 2) selected @endif>2</option>
                        <option value="3" @if($project->trimester == 3) selected @endif>3</option>
                    </select></td></tr>
                    @if ($errors->has('trimester'))
                        @foreach ($errors->get('trimester') as $error)
                            <tr><td></td><td><h4>{{ $error }}</h4></td></tr>
                        @endforeach
                    @endif
                    <tr><td colspan=2><input type="submit" value="Edit">
                <table>
            </form>
        </div>
    </div>

</section>
@endsection