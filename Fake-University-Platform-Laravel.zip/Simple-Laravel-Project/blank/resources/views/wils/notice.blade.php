@extends('layouts.default')

@section('page-content')
<section class="capsule">
            <div class="pill">
                    <h3 class="content-title">You have already applied for this project.</h3>
            </div>

</section>
@endsection