@extends('layouts.default')

@section('page-content')
<section class="capsule">
    <div class='pill'>
        <div class="content-shaper">
            <h3>Add Project: </h3>
            <form method="post" action=' {{url("wil")}} ' enctype="multipart/form-data">
                {{csrf_field()}}
                <table>
                    <tr><td><h3>Title: </h3></td><td><input type="text" name="title" value="{{ old('title') }}"></td></tr>
                    @if ($errors->has('title'))
                        @foreach ($errors->get('title') as $error)
                            <tr><td></td><td><h4>{{ $error }}</h4></td></tr>
                        @endforeach
                    @endif
                    <tr><td><h3>Image (optional): </h3></td><td><input type="file" name="image"></td></tr>
                    @if ($errors->has('image'))
                        @foreach ($errors->get('image') as $error)
                            <tr><td></td><td><h4>{{ $error }}</h4></td></tr>
                        @endforeach
                    @endif
                    <tr><td><h3>PDF file (optional): </h3></td><td><input type="file" name="pdf"></td></tr>
                    <tr><td><h3>Industry Partner: </h3></td><td><input type="text" name="industry_partner" value="{{Auth::user()->name}}"></td></tr>
                    @if ($errors->has('industry_partner'))
                        @foreach ($errors->get('industry_partner') as $error)
                            <tr><td></td><td><h4>{{ $error }}</h4></td></tr>
                        @endforeach
                    @endif
                    <tr><td><h3>Email: </h3></td><td><input type="text" name="email" value="{{Auth::user()->email}}"></td></tr>
                    @if ($errors->has('email'))
                        @foreach ($errors->get('email') as $error)
                            <tr><td></td><td><h4>{{ $error }}</h4></td></tr>
                        @endforeach
                    @endif
                    <tr><td><h3>Description: </h3></td><td><textarea name="description" rows="4">{{ old('description') }}</textarea></td></tr>
                    @if ($errors->has('description'))
                        @foreach ($errors->get('description') as $error)
                            <tr><td></td><td><h4>{{ $error }}</h4></td></tr>
                        @endforeach
                    @endif
                    <tr><td><h3>Students Needed (in numbers): </h3></td><td><input type="number" name="students_needed" value="{{ old('students_needed') }}"></td></tr>
                    @if ($errors->has('students_needed'))
                        @foreach ($errors->get('students_needed') as $error)
                            <tr><td></td><td><h4>{{ $error }}</h4></td></tr>
                        @endforeach
                    @endif
                    <tr><td><h3>Year: </h3></td><td><input type="number" name="year" value="{{ old('year') }}"></td></tr>
                    @if ($errors->has('year'))
                        @foreach ($errors->get('year') as $error)
                            <tr><td></td><td><h4>{{ $error }}</h4></td></tr>
                        @endforeach
                    @endif
                    <tr><td><h3>Trimester: </h3></td><td><select name="trimester" value="{{ old('trimester') }}">
                        <option value=1>1</option>
                        <option value=2>2</option>
                        <option value=3>3</option>
                    </select></td></tr>
                    @if ($errors->has('trimester'))
                        @foreach ($errors->get('trimester') as $error)
                            <tr><td></td><td><h4>{{ $error }}</h4></td></tr>
                        @endforeach
                    @endif
                    <tr><td colspan=2><input type="submit" value="Create">
                <table>
            </form>
        </div>
    </div>
</section>
@endsection