@extends('layouts.default')

@section('page-content')
<section class="capsule">
            <div class="pill">
                    <h3 class="content-title">You cannot apply for more than 3 projects.</h3>
            </div>

</section>
@endsection