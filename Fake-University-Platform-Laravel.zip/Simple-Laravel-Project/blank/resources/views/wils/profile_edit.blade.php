@extends('layouts.default')

@section('page-content')
<section class="capsule">
    <div class='pill'>
        <div class="content-shaper">
            <h3>Create Profile: </h3>
            <form method="post" action=' {{url("student/$profile->id")}} '>
                {{csrf_field()}}
                {{method_field('PUT')}}
                <table>
                    <tr><td><h4>GPA: <h4></td><td>
                    <select name="GPA">
                        <option value=0 @if($profile->GPA == 0) selected @endif>0</option>
                        <option value=1 @if($profile->GPA == 1) selected @endif>1</option>
                        <option value=2 @if($profile->GPA == 2) selected @endif>2</option>
                        <option value=3 @if($profile->GPA == 3) selected @endif>3</option>
                        <option value=4 @if($profile->GPA == 4) selected @endif>4</option>
                        <option value=5 @if($profile->GPA == 5) selected @endif>5</option>
                        <option value=6 @if($profile->GPA == 6) selected @endif>6</option>
                        <option value=7 @if($profile->GPA == 7) selected @endif>7</option>
                    </select>
                    <tr><td><h4>Check the roles you want to Apply for:</h4></td></tr>
                    @if (session()->has('role_error'))
                        <h5>{{ session('role_error') }}</h5>
                    @endif
                    <tr><td><h5>Software Developer: </h5></td><td><input type="checkbox" name="software_developer" value="1" @if($profile->software_developer) checked @endif></td></tr>
                    <tr><td><h5>Project Manager: </h5></td><td><input type="checkbox" name="project_manager" value="1" @if($profile->project_manager) checked @endif></td></tr>
                    <tr><td><h5>Business Analyst: </h5></td><td><input type="checkbox" name="business_analyst" value="1" @if($profile->business_analyst) checked @endif></td></tr>
                    <tr><td><h5>Tester: </h5></td><td><input type="checkbox" name="tester" value="1" @if($profile->tester) checked @endif></td></tr>
                    <tr><td><h5>Client Liaison: </h5></td><td><input type="checkbox" name="client_liaison" value="1" @if($profile->client_liaison) checked @endif></td></tr>
                    <tr><td colspan=2><input type="submit" value="Edit">
                <table>
            </form>
        </div>
    </div>
</section>
@endsection