@extends('layouts.default')

@section('page-content')
    <section class="capsule">
            <div class="pill">
                <h3 class="content-title">Posts</h3>
                @if(empty($groupedProjects))
                    <h2>There are no industry projects at the moment</h2>
                @else
                    @foreach ($groupedProjects as $year => $trimesters)
                        <h2>{{ $year }}</h2>
                        @foreach ($trimesters as $trimester => $projects)
                            <h3>- Trimester: {{ $trimester }}</h3>
                            <ul>
                                @foreach ($projects as $project)
                                    <li><a href=" project/{{$project->id}} " >{{ $project->title }}</a></li>
                                @endforeach
                            </ul>
                        @endforeach
                    @endforeach
                @endif
            </div>
    </section>

@endsection