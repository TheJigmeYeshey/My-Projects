@extends('layouts.default')

@section('page-content')
<section class="capsule">
            <div class="pill">
                        @if ($empty === 'yes')
                                <h3>Student has not created a profile.</h3>
                        @else
                                <h3 class="content-title">{{ $student->name }} </h3>
                                <h4>GPA: {{ $profile->GPA }}</h4>
                                <h4>Student has applied as:</h4>
                                <ol>
                                        @foreach ($array as $role) 
                                                <li>{{$role}}</li>
                                        @endforeach
                                </ol>
                                @if (Auth::user()->name === $student->name)
                                        <br>
                                        <h3><a href='{{url("student/$profile->id/edit")}}'>Click here to edit details.</a></h3>
                                @endif
                        @endif
                
            </div>

</section>
@endsection