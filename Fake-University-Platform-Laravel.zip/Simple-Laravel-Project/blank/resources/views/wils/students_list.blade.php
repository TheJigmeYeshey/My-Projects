@extends('layouts.default')

@section('page-content')
    <section class="capsule">
            <div class="pill">
                <h3 class="content-title">Students</h3>
                    <ol>
                        @foreach ($students as $student)
                                <li>
                                    <div class="title-date">
                                        <h2><a href="student/{{$student->id}}">{{$student->name}}</a></h2>
                                    </div>
                                </li>
                        @endforeach
                    </ol>
            </div>
    </section>

@endsection