@extends('layouts.default')

@section('page-content')
<section class="capsule">
            <div class="pill">
                    <h3 class="content-title">{{ $provider->name }}  ||  {{ $provider->email }}</h3>
                    <div class="content-shaper">
                                <h3> Projects </h3>
                                    @foreach ($projects as $project)
                                        <a href="../project/{{$project->id}}">
                                            <p class="content-text">
                                                - {{$project->title}}
                                            </p>
                                        </a>
                                    @endforeach
                    </div>
            </div>

</section>
@endsection