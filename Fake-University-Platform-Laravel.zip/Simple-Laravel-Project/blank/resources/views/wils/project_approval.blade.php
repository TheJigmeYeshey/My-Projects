@extends('layouts.default')

@section('page-content')
<section class="capsule">
            <div class="pill">
                    <h3 class="content-title">{{ $project->title }}  ||  Industry Partner: {{ $provider->name }}</h3>
                    <div class="content-shaper">
                                @if ($project->image != null)
                                    <img src="{{url($project->image)}}" alt="project image" style="width:300px;height:300px;">
                                @endif
                                <h3> Description </h3>
                                <p class="content-text">
                                    {{$project->description}}<br>
                                </p>
                                <p class="content-text">
                                    Students needed: {{ $project->students_needed }}
                                </p>
                                @if ($project->pdf != null)
                                    <a href="{{url($project->pdf)}}" download>Download PDF for more information.</a>
                                @endif
                                <br>
                                <br>
                                <form method="post" action=' {{url("teacher/$project->id")}} '>
                                    {{csrf_field()}}
                                    {{method_field('PUT')}}
                                        <table>
                                            <tr><td colspan=2><input type="submit" value="Approve">
                                        <table>
                                </form>
                    </div>
            </div>

</section>
@endsection