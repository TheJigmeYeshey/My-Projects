@extends('layouts.default')

@section('page-content')
    <section class="capsule">
            <div class="pill">
                <h3 class="content-title">Projects Pending for Approval</h3>
                    <ol>
                        @foreach ($projects as $project)
                                <li>
                                    <div class="title-date">
                                        <h2><a href="teacher/{{$project->id}}">{{$project->title}}</a></h2>
                                    </div>
                                </li>
                        @endforeach
                    </ol>
            </div>
    </section>

@endsection