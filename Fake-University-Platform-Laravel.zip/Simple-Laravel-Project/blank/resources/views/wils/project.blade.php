@extends('layouts.default')

@section('page-content')
<section class="capsule">
            <div class="pill">
                    <h3 class="content-title">{{ $project->title }}  ||  Industry Partner: {{ $provider->name }}</h3>
                    <div class="content-shaper">
                                @if ($project->image != null)
                                    <img src="{{url($project->image)}}" alt="project image" style="width:300px;height:300px;">
                                @endif
                                <h3> Description </h3>
                                <p class="content-text">
                                    {{$project->description}}<br>
                                </p>
                                <p class="content-text">
                                    Year: {{$project->year}}<br>
                                    Trimester: {{$project->trimester}}<br>
                                    Students needed: {{ $project->students_needed }}
                                </p>
                                @if ($project->pdf != null)
                                    <a href="{{url($project->pdf)}}" download>Download PDF for more information.</a>
                                @endif
                                <br>
                                <br>
                                @if ($assigned == true)
                                <h3>Assigned Students: </h3>
                                        <ul>
                                            @foreach ($users_assigned as $user_assigned)
                                                <li><h4>{{$user_assigned->name}}</h4></li>
                                                <p>GPA: {{$user_assigned->GPA}}</p>
                                            @endforeach
                                        </ul>
                                @else
                                    <h3>Applications: </h3>
                                        <ul>
                                            @foreach ($users as $user)
                                                <li><h4>{{$user->name}}</h4></li>
                                                <p>- "{{$user->pivot->justification}}"</p>
                                            @endforeach
                                        </ul>
                                @endif
                                @if ($student === 'yes')
                                    <h3>APPLY:</h3>
                                        @if ($updated === 'yes')
                                            <form method="post" action=' {{url("project")}} '>
                                                {{csrf_field()}}
                                                <table>
                                                    <tr><td><h3>Give a short justification: </h3></td><td><textarea name="justification" rows="4" ></textarea></td></tr>
                                                    @if ($errors->has('justification'))
                                                        @foreach ($errors->get('justification') as $error)
                                                            <tr><td></td><td><h4>{{ $error }}</h4></td></tr>
                                                        @endforeach
                                                    @endif
                                                    <input type="hidden" name="project_id" value="{{ $project->id }}">
                                                    <tr><td colspan=2><input type="submit" value="Apply">
                                                <table>
                                            </form>
                                        @else
                                            <p>You need to create a profile before you can apply for a project.</p>
                                            <h3><a href="{{url('student/create')}}">Click Here to Create Profile.</a></h3>
                                        @endif
                                @endif
                                @if ($inp === 'yes')
                                    @if (Auth::id() === $project->user_id)
                                        <br>
                                        <br>
                                        <br>
                                        <h3><a href='{{url("project/$project->id/edit")}}'>Click here to edit details.</a></h3>
                                        
                                        <h3>Click below to delete project.</h3>
                                            <div class="buttons">
                                                <form method="post" action='{{url("project/$project->id")}}'>
                                                    {{csrf_field()}}
                                                    {{ method_field('DELETE') }}
                                                    <input type="submit" value="Delete">
                                                </form>
                                                @if (session()->has('delete_error'))
                                                    <h5>{{ session('delete_error') }}</h5>
                                                @endif
                                            </div>
                                    @endif
                                @endif
                    </div>
            </div>

</section>
@endsection