@extends('layouts.default')

@section('page-content')
<section class="capsule">
            <div class="pill">
                    <h3 class="content-title">All students have been assigned to projects.</h3>
            </div>

</section>
@endsection