@extends('layouts.default')

@section('page-content')
    <section class="capsule">
            <div class="pill">
                <h3 class="content-title">Industry Partners</h3>
                @if(empty($providers))
                    <h2>There are no industry providers at the moment</h2>
                @else
                    @php
                        $author = [];
                    @endphp
                    <ol>
                        @foreach ($providers as $provider)
                            @if(in_array($provider->name, $author))
                            {{--no comment--}}
                            @else
                                <li>
                                    <div class="title-date">
                                        <h2><a href="wil/{{$provider->id}}"">{{$provider->name}}</a></h2>
                                    </div>
                                </li>
                                @php
                                    $author[] = $provider->name;
                                @endphp
                            @endif
                        @endforeach
                    </ol>
                    {{ $providers->links() }}
                    @if ($inp === 'yes')
                        <h3><a href='{{url("wil/create")}}'>Add Project</a></h3>
                    @endif
                    @if ($student == 'yes')
                        @if ($updated == 'no')
                            <h3><a href="{{url('student/create')}}">Click Here to Create Profile.</a></h3>
                        @endif
                    @endif
                    @if (Auth::check())
                        @if (Auth::user()->type === 'Teacher')
                            <form id="logout" method="POST" action='{{url("teacher")}}'>
                                {{csrf_field()}}
                                <input type="submit" value="Auto-Assign">
                            </form>
                        @endif
                    @endif
                @endif
            </div>
    </section>

@endsection