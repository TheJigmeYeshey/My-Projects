<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elmore</title>
    <link rel="stylesheet" href="{{asset('css/app.css')}}" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap">

</head>
<body>
    <header>
        <div class="container">
            @auth
                <h1>{{Auth::user()->type}}: <span id="more">{{Auth::user()->name}}</span></h1>
                @if (Auth::check())
                    <form id="logout" method="POST" action="{{url('/logout')}}">
                        {{csrf_field()}}
                        <input type="submit" value="Logout">
                    </form>
                @endif
                <nav>
                @if (Auth::user()->type === 'Teacher')
                        <a href="{{url('teacher')}}">Pending Approvals</a>
                    @endif
                    @if (Auth::user()->type === 'Student' && \App\Models\Profile::where('user_id', Auth::id())->exists())
                        <a href="{{url('student/'. Auth::user()->id)}}" class="nav-text">Profile</a>
                    @endif
                    @if (Auth::user()->type === 'Teacher')
                        <a href="{{url('student')}}">Students</a>
                    @endif
                    <a href="{{url('wil')}}" class="nav-text">Home</a>
                    <a href="{{url('project')}}" class="nav-text">Projects</a>
                </nav>
            @else
                <h1>El<span id="more">more</span></h1>
                <nav>
                    <a href="{{route('login')}}" class="nav-text">Log in</a>
                    <a href="{{route('register')}}" class="nav-text">Register</a>
                </nav>
            @endauth
        </div>
    </header>
    <main>
        @yield('page-content')
    </main>
    <footer>
        <div id='copyright'>
            <p>&copy; Jigme Yeshey | Assignment 1</p>
        </div>
    </footer>
</body>
</html>