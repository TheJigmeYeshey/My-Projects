<?php
namespace App;

class Comment{
    protected string $user;
    protected string $comment;
    protected string $date;
    
    // defines the properties of the object on creation
    function __construct($user, $comment, $date){
        $this->user = $user;
        $this->comment = $comment;
        $this->date = $date;
    }
    
    //returns the property user of the object created
    function getUser(): string{
        return $this->user;
    }
    
    //returns the property comment of the object created
    function getComment(): string{
        return $this->comment;
    }

    function getDate(): string{
        return $this->date;
    }
}
?>