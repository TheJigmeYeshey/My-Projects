<?php
    namespace App;
    use App\Comment;
    include 'Comment.php';

    class Post{
        public string $title;
        protected string $author;
        public string $message;
        protected string $date;
        protected string $id;
        protected array $comments = []; 
    
        //initializes the properties of the object on creation
        function __construct($title, $author, $message, $date, $id){
            $this->title = $title;
            $this->author = $author;
            $this->message = $message;
            $this->date = $date;
            $this->id = $id;
            $this->comments = [];
        }
    
        //returns the property title of the object
        function getTitle(): string{
            return $this->title;
        }
    
        //returns the property message of the object
        function getMessage(): string{
            return $this->message;
        }
    
        //returns the property author of the object
        function getAuthor(): string{
            return $this->author;
        }

        function getDate(): string{
            return $this->date;
        }

        function getID(): string{
            return $this->id;
        }
        
        //returns the property comments of the object
        function getComment(): array{
            return $this->comments;
        }
        
        //stores the user and their comment in the initialized array called comments.
        function addComment($user, $comment, $date)
        {
            $this->comments[] = new Comment($user, $comment, $date);
        }
        
    }

?>

