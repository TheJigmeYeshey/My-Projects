<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Provider;
use App\Models\Project;
use App\Models\User;
use App\Models\Offering;
use App\Models\Application;
use App\Models\Profile;
use App\Models\Approval;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class WilController extends Controller
{
    function __construct(){
        $this->middleware('auth', ['except'=>['index']]);
    }

    //Shows a list of industry partners and provides parameters for pagination
    public function index()
    {
        $inp= '';
        $student = '';
        $updated = '';
        $providers = User::where('type', 'Industry Partner')->paginate(5);


        if (Auth::check()){
            $user = Auth::user();
            if ($user->type === "Industry Partner") {
                $inp ='yes';
            } else {
                $inp = 'no';
            }

            $profile = Profile::where('user_id', Auth::id())->exists();

            if ($profile) {
                $updated = 'yes';
            } else {
                $updated = 'no';
            }
    
            $user = Auth::user();
            if ($user->type === "Student") {
                $student ='yes';
            } else {
                $student = 'no';
            }
        }

        return view('wils.providers_list')->with('providers', $providers)->with('inp', $inp)->with('student', $student)->with('updated', $updated);
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('wils.create');
        //
    }

    //Creates a new row in the projects table.
    public function store(Request $request)
    {
        $validationRules = [
            'title' => 'required|max:255|min:5',
            'description' => 'required|max:255',
            'students_needed' => 'required|integer|between:3,6',
            'year' => 'required|integer',
            'trimester' => 'required|integer',
        ];

        $validator = Validator::make($request->all(), $validationRules);

        $wordCount = str_word_count($request->description);

        $existingProject = Project::where('title', $request->title)
            ->where('year', $request->year)
            ->where('trimester', $request->trimester)
            ->first();
            
        if ($existingProject) {
            $validator->after(function ($validator) {
                $validator->errors()->add('title', 'A project with the same name already exists in the same trimester and year.');
            });
        }

        if ($wordCount<3) {
            $validator->after(function ($validator) {
                $validator->errors()->add('description', 'Description field requires at least three words.');
            });
        }

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        $project = new Project();

        if ($request->file('image')) {
            $image_store=request()->file('image')->store('projects_images', 'public');
            $project->image = $image_store;
        }
        if ($request->file('pdf')) {
            $pdf_store=request()->file('pdf')->store('pdfs_images', 'public');
            $project->pdf = $pdf_store;
        }
        
        $project->title = $request->title;
        $project->description = $request->description;
        $project->students_needed = $request->students_needed;
        $project->year = $request->year;
        $project->trimester = $request->trimester;
        $user = User::where('name', $request->industry_partner)->first();
        $project->user_id = $user->id;
        $project->save();

        $approval = new Approval();
        $approval->status = "pending";
        $approval->project_id = $project -> id;
        $approval->save();

        $existingProject = Project::where('title', $request->title)
        ->where('year', $request->year)
        ->where('trimester', $request->trimester)
        ->first();

        return redirect('wil');
        
        //
    }

    //Shows the details of industry partners and the projects they are offering.
    public function show(string $id)
    {
        $provider = User::where('id', $id)->first();

        $projects = Project::join('approvals', 'projects.id', '=', 'approvals.project_id')->where('projects.user_id', $id)->where('approvals.status', 'approved')->get();

        return view('wils.provider')->with('provider', $provider)->with('projects', $projects);  
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
