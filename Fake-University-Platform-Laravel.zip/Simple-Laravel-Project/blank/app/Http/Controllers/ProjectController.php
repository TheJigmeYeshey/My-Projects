<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Provider;
use App\Models\Project;
use App\Models\User;
use App\Models\Offering;
use App\Models\Application;
use App\Models\Profile;
use App\Models\Approval;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class ProjectController extends Controller
{
    function __construct(){
        $this->middleware('auth', ['except'=>['index']]);
    }

    //Returns a view of projects arranged in descending order of year first and trimester second.
    public function index()
    {

        $projects = Project::join('approvals', 'projects.id', '=', 'approvals.project_id')->where('approvals.status', 'approved')->orderBy('projects.year', 'desc')->orderBy('projects.trimester', 'desc')->select('projects.*')->get();    

        $groupedProjects = [];

        foreach ($projects as $project) {
            $year = $project->year;
            $trimester = $project->trimester;
            
            if (!isset($groupedProjects[$year])) {
                $groupedProjects[$year] = [];
            }
            
            if (!isset($groupedProjects[$year][$trimester])) {
                $groupedProjects[$year][$trimester] = [];
            }
            
            $groupedProjects[$year][$trimester][] = $project;
        }
            return view('wils.projects_list')->with('groupedProjects', $groupedProjects);
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    //Creates a new row in applications table when student applies for a project.
    public function store(Request $request)
    {

        $this->validate($request, [
            'justification' => 'required|max:255'
        ]);

        $user_id = Auth::id();
        
        $project_id = $request -> project_id;

        $count = Application::where('user_id', $user_id)->count();

        $exists = Application::where('user_id', $user_id)->where('project_id', $project_id)->exists();

        if ($count === 3) {
            return view ('wils.restricted');
        } else {

            if ($exists) {
                return view('wils.notice');
            } else {
                $application = new Application();
                $application->justification = $request->justification;
                $application->user_id = $user_id;
                $application->project_id = $project_id;
                $application->approved = 'no';
                $application->save();

                return redirect('project');
            }
        }
        
        //
    }

    //Returns a view of project details.
    public function show(string $id)
    {   
        $student = '';
        $inp = '';
        $provider = '';
        $assigned = false;

        $profile = Profile::where('user_id', Auth::id())->exists();

        if ($profile) {
            $updated = 'yes';
        } else {
            $updated = 'no';
        }

        $user = Auth::user();
        if ($user->type === "Student") {
            $student ='yes';
        } else {
            $student = 'no';
        }

        if ($user->type === "Industry Partner") {
            $inp ='yes';
        } else {
            $inp = 'no';
        }
        

        $project = Project::where('id', $id)->first();

        $users = $project->needs;

        $users_assigned = User::join('applications', 'users.id', '=', 'applications.user_id')->join('profiles', 'users.id', '=', 'profiles.user_id')->where('applications.project_id', '=', $project->id)->where('applications.approved', '=', 'yes')->select('users.*', 'profiles.*')->get();

        if (count($users_assigned)>0) {
            $assigned = true;
        }

        $provider = User::join('projects', 'users.id', '=', 'projects.user_id')
                    ->select('users.*')
                    ->where('projects.id', $id)->first();

        return view('wils.project')->with('project', $project)->with('provider', $provider)->with('users', $users)->with('student', $student)->with('inp', $inp)->with('updated', $updated)->with('users_assigned', $users_assigned)->with('assigned', $assigned);
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {   
        $project = Project::find($id);
        
        return view('wils.edit')->with('project', $project);
        //
    }

    //Updates the new values of project on an existing row in the projects table.
    public function update(Request $request, string $id)
    {

        $validationRules = [
            'title' => 'required|max:255|min:5',
            'description' => 'required|max:255',
            'students_needed' => 'required|integer|between:3,6',
            'year' => 'required|integer',
            'trimester' => 'required|integer',
        ];

        $validator = Validator::make($request->all(), $validationRules);

        $wordCount = str_word_count($request->description);

        $existingProject = Project::where('title', $request->title)
            ->where('year', $request->year)
            ->where('trimester', $request->trimester)
            ->first();
        
        if ($existingProject) {
            $validator->after(function ($validator) {
                $validator->errors()->add('title', 'A project with the same name already exists in the same trimester and year.');
            });
        }

        if ($wordCount<3) {
            $validator->after(function ($validator) {
                $validator->errors()->add('description', 'Description field requires at least three words.');
            });
        }

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }
        

        $project = Project::find($id);
        $project->title = $request->title;
        $project->description =$request->description;
        $project->students_needed =$request->students_needed;
        $project->year =$request->year;
        $project->trimester =$request->trimester;

        if ($request->image != null) {
            $image_store=request()->file('image')->store('projects_images', 'public');
            $project->image = $image_store;
        }

        if ($request->pdf != null) {
            $pdf_store=request()->file('pdf')->store('pdfs_images', 'public');
            $project->pdf = $pdf_store;
        }

        $project->save();
        return redirect("project/$project->id");
        //
    }

    //Deletes a row from the projects table and rows from other tables linked to it.
    public function destroy(string $id)
    {   
        $project = Project::find($id);
        $users = $project->needs;
        $approval = Approval::where('project_id', $id);

        if ($users->count() > 0) {
            // Redirect with an error message.
            return redirect()->back()->with('delete_error', 'Projects that have students applied to work cannot be deleted.');
        } else {
            $approval->delete();
            $project->delete();
            return redirect('project');
        }
        //
    }
}
