<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Provider;
use App\Models\Project;
use App\Models\User;
use App\Models\Offering;
use App\Models\Application;
use App\Models\Profile;
use App\Models\Approval;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class StudentController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $students = User::where('type', 'Student')->get();

        return view('wils.students_list')->with('students', $students);
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('wils.profile_create');
        //
    }

    //Creates a new row in profiles table
    public function store(Request $request)
    {
        $user_id = Auth::id();

        if (
            !$request->has('software_developer') &&
            !$request->has('project_manager') &&
            !$request->has('business_analyst') &&
            !$request->has('tester') &&
            !$request->has('client_liaison')
        ) {
            return redirect()->back()->with('role_error', '***At least one role must be selected.***');
        } else {

            $profile = new Profile();
        
            $profile->GPA = intval($request->GPA);
            $profile->software_developer = $request->has('software_developer');
            $profile->project_manager = $request->has('project_manager');
            $profile->business_analyst = $request->has('business_analyst');
            $profile->tester = $request->has('tester');
            $profile->client_liaison = $request->has('client_liaison');
            $profile->user_id = $user_id;
            
            $profile->save(); 
    
            return redirect('wil');
        }

    }

    //Displays the profile details of students
    public function show(string $id)
    {
        $student = User::find($id);
        $profile = Profile::where('user_id', $student->id)->first();

        if (!empty($profile)) {
            $empty = 'no';

            $array = [];
    
            if ($profile->software_developer) {
                $array [] = 'Software Developer';
            }
            if ($profile->project_manager){
                $array [] = 'Project Manager';
            }
            if ($profile->business_analyst){
                $array [] = 'Business Analyst';
            }
            if ($profile->tester){
                $array [] = 'Tester';
            }
            if ($profile->client_liaison){
                $array [] = 'Client Liaison';
            }
    
            return view('wils.profile')->with('student', $student)->with('profile', $profile)->with('array', $array)->with('empty', $empty);
        } else {
            $empty = 'yes';
            return view('wils.profile')->with('empty', $empty);
        }
        //
    }

    //returns the profile editing page when user clicks on the editing link.
    public function edit(string $id)
    {
        $profile = Profile::find($id);

        return view('wils.profile_edit')->with('profile', $profile);
        
        //
    }

    //updates new row values on the profiles table
    public function update(Request $request, string $id)
    {
        $profile = Profile::find($id);
        $user_id = Auth::id();

        if (
            !$request->has('software_developer') &&
            !$request->has('project_manager') &&
            !$request->has('business_analyst') &&
            !$request->has('tester') &&
            !$request->has('client_liaison')
        ) {
            return redirect()->back()->with('role_error', '***At least one role must be selected.***');
        } else {
            
            $profile->GPA = intval($request->GPA);
            $profile->software_developer = $request->has('software_developer');
            $profile->project_manager = $request->has('project_manager');
            $profile->business_analyst = $request->has('business_analyst');
            $profile->tester = $request->has('tester');
            $profile->client_liaison = $request->has('client_liaison');
            $profile->user_id = $user_id;
            
            $profile->save(); 
    
            return redirect("student/$user_id");
        }

        
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
