<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Provider;
use App\Models\Project;
use App\Models\User;
use App\Models\Offering;
use App\Models\Application;
use App\Models\Profile;
use App\Models\Approval;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class TeacherController extends Controller
{
    //displays the projects pending for approval that can only be viewed by the teacher.
    public function index()
    {
        $projects = Project::join('approvals', 'projects.id', '=', 'approvals.project_id')->where('approvals.status', 'pending')->get();
        return view('wils.approvals_list')->with('projects', $projects);
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    //auto-assigns students who have applied to a project based on their GPA.
    public function store(Request $request)
    {

        $applications = Application::join('users', 'applications.user_id', '=', 'users.id')->join('profiles', 'users.id', '=', 'profiles.user_id')->orderBy('profiles.GPA', 'desc')->select('applications.*')->get();
        $array = [];

        foreach ($applications as $application){
            $project = Project::where('id', $application->project_id)->first();

            if ($project->students_needed != 0){
                $application->approved = 'yes';
                $application->save();
                $project->students_needed -= 1;
                $project->save();
            }
        }

        $rejects = Application::where('approved', 'no')->get();

        foreach ($rejects as $reject){
            $project = Project::where('students_needed', '>', 0)->first();

            if ($project->students_needed != 0){
                $reject->project_id = $project->id;
                $reject->approved = 'yes';
                $reject->save();
                $project->students_needed -= 1;
                $project->save();
            }
        }

        return view('wils.assigned');

        //
    }

    //Shows the details of projects pending for approval.
    public function show(string $id)
    {
        $project = Project::find($id);


        $provider = User::join('projects', 'users.id', '=', 'projects.user_id')
        ->select('users.*')
        ->where('projects.id', $id)->first();

        return view('wils.project_approval')->with('project', $project)->with('provider', $provider);
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    //updates the approvals table so that students can start applying to it.
    public function update(Request $request, string $id)
    {
        $approval = Approval::where('project_id', $id)->first();
        
        $approval->status = "approved";

        $approval->save();

        return redirect('wil');
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
