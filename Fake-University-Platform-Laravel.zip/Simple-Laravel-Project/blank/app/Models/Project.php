<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
    use HasFactory;
    function users() {
        return $this->belongsTo('App\Models\User');
    }

    function needs() {
        return $this->belongsToMany('App\Models\User', 'applications')->withPivot('justification')->withTimestamps();
    }

}
