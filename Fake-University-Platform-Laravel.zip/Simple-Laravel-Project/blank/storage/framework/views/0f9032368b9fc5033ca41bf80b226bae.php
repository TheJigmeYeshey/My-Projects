<?php $__env->startSection('page-content'); ?>
    <section class="capsule">
            <div class="pill">
                <h3 class="content-title">Industry Partners</h3>
                <?php if(empty($providers)): ?>
                    <h2>There are no industry providers at the moment</h2>
                <?php else: ?>
                    <?php
                        $author = [];
                    ?>
                    <ol>
                        <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(in_array($provider->name, $author)): ?>
                            
                            <?php else: ?>
                                <li>
                                    <div class="title-date">
                                        <h2><a href="wil/<?php echo e($provider->id); ?>""><?php echo e($provider->name); ?></a></h2>
                                    </div>
                                </li>
                                <?php
                                    $author[] = $provider->name;
                                ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>
                    <?php echo e($providers->links()); ?>

                    <?php if($inp === 'yes'): ?>
                        <h3><a href='<?php echo e(url("wil/create")); ?>'>Add Project</a></h3>
                    <?php endif; ?>
                    <?php if($student == 'yes'): ?>
                        <?php if($updated == 'no'): ?>
                            <h3><a href="<?php echo e(url('student/create')); ?>">Click Here to Create Profile.</a></h3>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if(Auth::check()): ?>
                        <?php if(Auth::user()->type === 'Teacher'): ?>
                            <form id="logout" method="POST" action='<?php echo e(url("teacher")); ?>'>
                                <?php echo e(csrf_field()); ?>

                                <input type="submit" value="Auto-Assign">
                            </form>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/AssignmentTwo/blank/resources/views/wils/providers_list.blade.php ENDPATH**/ ?>