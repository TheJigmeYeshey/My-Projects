<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elmore</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap">

</head>
<body>
    <header>
        <div class="container">
            <?php if(auth()->guard()->check()): ?>
                <h1><?php echo e(Auth::user()->type); ?>: <span id="more"><?php echo e(Auth::user()->name); ?></span></h1>
                <?php if(Auth::check()): ?>
                    <form id="logout" method="POST" action="<?php echo e(url('/logout')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <input type="submit" value="Logout">
                    </form>
                <?php endif; ?>
                <nav>
                <?php if(Auth::user()->type === 'Teacher'): ?>
                        <a href="<?php echo e(url('teacher')); ?>">Pending Approvals</a>
                    <?php endif; ?>
                    <?php if(Auth::user()->type === 'Student' && \App\Models\Profile::where('user_id', Auth::id())->exists()): ?>
                        <a href="<?php echo e(url('student/'. Auth::user()->id)); ?>" class="nav-text">Profile</a>
                    <?php endif; ?>
                    <?php if(Auth::user()->type === 'Teacher'): ?>
                        <a href="<?php echo e(url('student')); ?>">Students</a>
                    <?php endif; ?>
                    <a href="<?php echo e(url('wil')); ?>" class="nav-text">Home</a>
                    <a href="<?php echo e(url('project')); ?>" class="nav-text">Projects</a>
                </nav>
            <?php else: ?>
                <h1>El<span id="more">more</span></h1>
                <nav>
                    <a href="<?php echo e(route('login')); ?>" class="nav-text">Log in</a>
                    <a href="<?php echo e(route('register')); ?>" class="nav-text">Register</a>
                </nav>
            <?php endif; ?>
        </div>
    </header>
    <main>
        <?php echo $__env->yieldContent('page-content'); ?>
    </main>
    <footer>
        <div id='copyright'>
            <p>&copy; Jigme Yeshey | Assignment 1</p>
        </div>
    </footer>
</body>
</html><?php /**PATH /var/www/html/AssignmentTwo/blank/resources/views/layouts/default.blade.php ENDPATH**/ ?>