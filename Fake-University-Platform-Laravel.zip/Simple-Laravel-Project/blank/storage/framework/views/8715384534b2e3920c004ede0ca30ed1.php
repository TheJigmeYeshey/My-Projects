<?php $__env->startSection('page-content'); ?>
<section class="capsule">
            <div class="pill">
                        <?php if($empty === 'yes'): ?>
                                <h3>Student has not created a profile.</h3>
                        <?php else: ?>
                                <h3 class="content-title"><?php echo e($student->name); ?> </h3>
                                <h4>GPA: <?php echo e($profile->GPA); ?></h4>
                                <h4>Student has applied as:</h4>
                                <ol>
                                        <?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                <li><?php echo e($role); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ol>
                                <?php if(Auth::user()->name === $student->name): ?>
                                        <br>
                                        <h3><a href='<?php echo e(url("student/$profile->id/edit")); ?>'>Click here to edit details.</a></h3>
                                <?php endif; ?>
                        <?php endif; ?>
                
            </div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/AssignmentTwo/blank/resources/views/wils/profile.blade.php ENDPATH**/ ?>