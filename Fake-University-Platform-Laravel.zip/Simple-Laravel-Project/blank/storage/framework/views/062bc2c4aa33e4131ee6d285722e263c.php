<?php $__env->startSection('page-content'); ?>
    <section class="capsule">
            <div class="pill">
                <h3 class="content-title">Posts</h3>
                <?php if(empty($posts)): ?>
                    <h2>There are no users at the moment</h2>
                <?php else: ?>
                    <?php
                        $author = [];
                    ?>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(in_array($post->P_Author, $author)): ?>
                        
                        <?php else: ?>
                            <div class="title-date">
                                <h2><a href="<?php echo e(url("list/$post->P_Author")); ?>""><?php echo e($post->P_Author); ?></a></h2>
                            </div>
                            <?php
                                $author[] = $post->P_Author;
                            ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Assignment/blank/resources/views/users.blade.php ENDPATH**/ ?>