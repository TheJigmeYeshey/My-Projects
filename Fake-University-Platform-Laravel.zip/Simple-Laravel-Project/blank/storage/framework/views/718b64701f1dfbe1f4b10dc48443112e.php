<?php $__env->startSection('page-content'); ?>
<section class="capsule">
            <div class="pill">
                    <h3 class="content-title"><?php echo e($project->title); ?>  ||  Industry Partner: <?php echo e($provider->name); ?></h3>
                    <div class="content-shaper">
                                <?php if($project->image != null): ?>
                                    <img src="<?php echo e(url($project->image)); ?>" alt="project image" style="width:300px;height:300px;">
                                <?php endif; ?>
                                <h3> Description </h3>
                                <p class="content-text">
                                    <?php echo e($project->description); ?><br>
                                </p>
                                <p class="content-text">
                                    Year: <?php echo e($project->year); ?><br>
                                    Trimester: <?php echo e($project->trimester); ?><br>
                                    Students needed: <?php echo e($project->students_needed); ?>

                                </p>
                                <?php if($project->pdf != null): ?>
                                    <a href="<?php echo e(url($project->pdf)); ?>" download>Download PDF for more information.</a>
                                <?php endif; ?>
                                <br>
                                <br>
                                <?php if($assigned == true): ?>
                                <h3>Assigned Students: </h3>
                                        <ul>
                                            <?php $__currentLoopData = $users_assigned; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_assigned): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><h4><?php echo e($user_assigned->name); ?></h4></li>
                                                <p>GPA: <?php echo e($user_assigned->GPA); ?></p>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                <?php else: ?>
                                    <h3>Applications: </h3>
                                        <ul>
                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><h4><?php echo e($user->name); ?></h4></li>
                                                <p>- "<?php echo e($user->pivot->justification); ?>"</p>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                <?php endif; ?>
                                <?php if($student === 'yes'): ?>
                                    <h3>APPLY:</h3>
                                        <?php if($updated === 'yes'): ?>
                                            <form method="post" action=' <?php echo e(url("project")); ?> '>
                                                <?php echo e(csrf_field()); ?>

                                                <table>
                                                    <tr><td><h3>Give a short justification: </h3></td><td><textarea name="justification" rows="4" ></textarea></td></tr>
                                                    <?php if($errors->has('justification')): ?>
                                                        <?php $__currentLoopData = $errors->get('justification'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr><td></td><td><h4><?php echo e($error); ?></h4></td></tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                    <input type="hidden" name="project_id" value="<?php echo e($project->id); ?>">
                                                    <tr><td colspan=2><input type="submit" value="Apply">
                                                <table>
                                            </form>
                                        <?php else: ?>
                                            <p>You need to create a profile before you can apply for a project.</p>
                                            <h3><a href="<?php echo e(url('student/create')); ?>">Click Here to Create Profile.</a></h3>
                                        <?php endif; ?>
                                <?php endif; ?>
                                <?php if($inp === 'yes'): ?>
                                    <?php if(Auth::id() === $project->user_id): ?>
                                        <br>
                                        <br>
                                        <br>
                                        <h3><a href='<?php echo e(url("project/$project->id/edit")); ?>'>Click here to edit details.</a></h3>
                                        
                                        <h3>Click below to delete project.</h3>
                                            <div class="buttons">
                                                <form method="post" action='<?php echo e(url("project/$project->id")); ?>'>
                                                    <?php echo e(csrf_field()); ?>

                                                    <?php echo e(method_field('DELETE')); ?>

                                                    <input type="submit" value="Delete">
                                                </form>
                                                <?php if(session()->has('delete_error')): ?>
                                                    <h5><?php echo e(session('delete_error')); ?></h5>
                                                <?php endif; ?>
                                            </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                    </div>
            </div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/AssignmentTwo/blank/resources/views/wils/project.blade.php ENDPATH**/ ?>