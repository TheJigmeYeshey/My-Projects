<?php $__env->startSection('page-content'); ?>
<section class="capsule">
    <div class='pill'>
            <h3 class="content-title">Edit Post</h3>
            <form method="post" action="edited_details">
                <?php echo e(csrf_field()); ?>

                        <table>
                            <tr><td><h3>Title: </h3></td><td><input type="text" name="title" value="<?php echo e($post->P_Title); ?>"></td></tr>
                            <h3> <?php echo e($post->P_Author); ?>  ||  <?php echo e($post->P_Date); ?></h3>
                            <tr><td><h3>Message: </h3></td><td><textarea name="message" rows="4"><?php echo e($post->P_Message); ?></textarea></td></tr>
                            <input type="hidden" name="id" value="<?php echo e($post->PostID); ?>">
                            <tr><td colspan=2><input type="submit" value="Submit"></td?<tr>
                        <table>
            </form>
    </div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Assignment/blank/resources/views/edit.blade.php ENDPATH**/ ?>