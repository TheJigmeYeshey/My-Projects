<?php $__env->startSection('page-content'); ?>
<section class="capsule">
    <div class='pill'>
        <div class="content-shaper">
            <h3>Create Profile: </h3>
            <form method="post" action=' <?php echo e(url("student")); ?> '>
                <?php echo e(csrf_field()); ?>

                <table>
                    <tr><td><h4>GPA: <h4></td><td>
                    <select name="GPA">
                        <option value=0>0</option>
                        <option value=1>1</option>
                        <option value=2>2</option>
                        <option value=3>3</option>
                        <option value=4>4</option>
                        <option value=5>5</option>
                        <option value=6>6</option>
                        <option value=7>7</option>
                    </select></td></tr>

                    <tr><td><h4>Check the roles you want to Apply for:</h4></td></tr>
                    <?php if(session()->has('role_error')): ?>
                        <h5><?php echo e(session('role_error')); ?></h5>
                    <?php endif; ?>
                    <tr><td><h5>Software Developer: </h5></td><td><input type="checkbox" name="software_developer" value="1"></td></tr>
                    <tr><td><h5>Project Manager: </h5></td><td><input type="checkbox" name="project_manager" value="1"></td></tr>
                    <tr><td><h5>Business Analyst: </h5></td><td><input type="checkbox" name="business_analyst" value="1"></td></tr>
                    <tr><td><h5>Tester: </h5></td><td><input type="checkbox" name="tester" value="1"></td></tr>
                    <tr><td><h5>Client Liaison: </h5></td><td><input type="checkbox" name="client_liaison" value="1"></td></tr>
                    <tr><td colspan=2><input type="submit" value="Create">
                <table>
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/AssignmentTwo/blank/resources/views/wils/profile_create.blade.php ENDPATH**/ ?>