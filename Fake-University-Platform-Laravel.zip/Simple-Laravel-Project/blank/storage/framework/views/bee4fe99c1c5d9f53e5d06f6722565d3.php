<?php $__env->startSection('page-content'); ?>
    <section class="capsule">
            <div class="pill">
                <h3 class="content-title">Posts</h3>
                <?php if(empty($groupedProjects)): ?>
                    <h2>There are no industry projects at the moment</h2>
                <?php else: ?>
                    <?php $__currentLoopData = $groupedProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year => $trimesters): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h2><?php echo e($year); ?></h2>
                        <?php $__currentLoopData = $trimesters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trimester => $projects): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h3>- Trimester: <?php echo e($trimester); ?></h3>
                            <ul>
                                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href=" project/<?php echo e($project->id); ?> " ><?php echo e($project->title); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/AssignmentTwo/blank/resources/views/wils/projects_list.blade.php ENDPATH**/ ?>