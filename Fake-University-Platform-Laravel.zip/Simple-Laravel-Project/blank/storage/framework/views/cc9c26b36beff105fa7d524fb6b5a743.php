<?php $__env->startSection('page-content'); ?>
<section class="capsule">
            <div class="pill">
                    <h3 class="content-title">All students have been assigned to projects.</h3>
            </div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/AssignmentTwo/blank/resources/views/wils/assigned.blade.php ENDPATH**/ ?>