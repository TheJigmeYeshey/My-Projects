<?php $__env->startSection('page-content'); ?>
<section class="capsule">
            <div class="pill">
                    <h3 class="content-title"><?php echo e($provider->name); ?>  ||  <?php echo e($provider->email); ?></h3>
                    <div class="content-shaper">
                                <h3> Projects </h3>
                                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="../project/<?php echo e($project->id); ?>">
                                            <p class="content-text">
                                                - <?php echo e($project->title); ?>

                                            </p>
                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                    </div>
            </div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/AssignmentTwo/blank/resources/views/wils/details.blade.php ENDPATH**/ ?>