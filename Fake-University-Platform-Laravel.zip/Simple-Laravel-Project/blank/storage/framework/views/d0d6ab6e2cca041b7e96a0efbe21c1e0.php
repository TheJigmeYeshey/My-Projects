<?php $__env->startSection('page-content'); ?>
<section class="capsule">
            <div class="pill">
                    <h3 class="content-title">Application</h3>
                    <div class="content-shaper">
                                <h3>Tell us why you want to apply.</h3>
                                <form method="post" action=' <?php echo e(url("project")); ?> '>
                                    <?php echo e(csrf_field()); ?>

                                    <table>
                                        <tr><td><h3>justification: </h3></td><td><textarea name="justification" rows="4" ></textarea></td></tr>
                                        <?php if($errors->has('justification')): ?>
                                            <?php $__currentLoopData = $errors->get('justification'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr><td></td><td><h4><?php echo e($error); ?></h4></td></tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        <tr><td colspan=2><input type="submit" value="Create">
                                    <table>
                                </form>
                    </div>
            </div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/AssignmentTwo/blank/resources/views/wils/application.blade.php ENDPATH**/ ?>