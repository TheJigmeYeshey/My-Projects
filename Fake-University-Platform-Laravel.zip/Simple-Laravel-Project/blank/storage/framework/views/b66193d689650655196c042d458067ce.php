<?php $__env->startSection('page-content'); ?>
<section class="capsule">
    <div class='pill'>
            <h3 class="content-title">Reply to <?php echo e($user); ?></h3>
            <form method="post" action="update_comment">
                <?php echo e(csrf_field()); ?>

                <table>
                    <tr><td><h3>Author: </h3></td><td><input type="text" name="user" value="<?php echo e($username); ?>"></td></tr>
                    <tr><td><h3>Message: </h3></td><td><textarea name="comment" rows="4"></textarea></td></tr>
                    <input type="hidden" name="name" value="<?php echo e($user); ?>">
                    <input type="hidden" name="postID" value="<?php echo e($postID); ?>">
                    <input type="hidden" name="commentID" value="<?php echo e($commentID); ?>">
                    <tr><td colspan=2><input type="submit" value="Submit">
                <table>
            </form>
    </div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Assignment/blank/resources/views/reply.blade.php ENDPATH**/ ?>