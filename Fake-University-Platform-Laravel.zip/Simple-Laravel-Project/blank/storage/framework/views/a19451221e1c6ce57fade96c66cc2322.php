<?php $__env->startSection('page-content'); ?>
    <section id="title">
        <div id="title2">
            <h2 id="el">El <span id="more">more</span></h2>
            <he id="myname">by Jigme Yeshey</he>
        </div>
    </section>
    <section class="capsule">
        <div class="pill">
            <h3 class="content-title">Posts</h3>
            <?php if(empty($posts)): ?>
                <h2>There are no posts at the moment</h2>
            <?php else: ?>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="content-shaper">
                            <div class="content-bg" class>
                                <div class="title-date">
                                    <h2><a href="<?php echo e(url("details/$post->PostID")); ?>"><?php echo e($post->P_Title); ?></a> || Comments: <?php echo e($post->TotalComments); ?> || Likes: <?php echo e($post->TotalLikes); ?></h2>
                                    <h6><?php echo e($post->P_Date); ?></h6>
                                </div>
                                <div class="post-auth">
                                    <p class="content-text">
                                        By <?php echo e($post->P_Author); ?>

                                    </p>
                                </div>
                            </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    <div class='pill'>
            <h3 class="content-title">Create Post</h3>
            <form method="post" action="<?php echo e(url("create_post")); ?>">
                <?php echo e(csrf_field()); ?>

                    <?php if(count($errors) != 0): ?>
                        <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h3 id="red"><?php echo e($error); ?></h3>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <table>
                        <tr><td><h3>Title: </h3></td><td><input type="text" name="title"></td></tr>
                        <tr><td><h3>Author: </h3></td><td><input type="text" name="author" value="<?php echo e($username); ?>"></td></tr>
                        <tr><td><h3>Message: </h3></td><td><textarea name="message" rows="4"></textarea></td></tr>
                        <tr><td colspan=2><input type="submit" value="Submit">
                    </table>
            </form>
    </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Assignment/blank/resources/views/index.blade.php ENDPATH**/ ?>