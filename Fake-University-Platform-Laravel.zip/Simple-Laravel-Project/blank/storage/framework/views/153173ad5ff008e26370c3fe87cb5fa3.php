<?php $__env->startSection('page-content'); ?>
<section class="capsule">
    <div class='pill'>
        <div class="content-shaper">
            <h3>Add Project: </h3>
            <form method="post" action=' <?php echo e(url("wil")); ?> ' enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <table>
                    <tr><td><h3>Title: </h3></td><td><input type="text" name="title" value="<?php echo e(old('title')); ?>"></td></tr>
                    <?php if($errors->has('title')): ?>
                        <?php $__currentLoopData = $errors->get('title'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr><td></td><td><h4><?php echo e($error); ?></h4></td></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <tr><td><h3>Image (optional): </h3></td><td><input type="file" name="image"></td></tr>
                    <?php if($errors->has('image')): ?>
                        <?php $__currentLoopData = $errors->get('image'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr><td></td><td><h4><?php echo e($error); ?></h4></td></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <tr><td><h3>PDF file (optional): </h3></td><td><input type="file" name="pdf"></td></tr>
                    <tr><td><h3>Industry Partner: </h3></td><td><input type="text" name="industry_partner" value="<?php echo e(Auth::user()->name); ?>"></td></tr>
                    <?php if($errors->has('industry_partner')): ?>
                        <?php $__currentLoopData = $errors->get('industry_partner'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr><td></td><td><h4><?php echo e($error); ?></h4></td></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <tr><td><h3>Email: </h3></td><td><input type="text" name="email" value="<?php echo e(Auth::user()->email); ?>"></td></tr>
                    <?php if($errors->has('email')): ?>
                        <?php $__currentLoopData = $errors->get('email'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr><td></td><td><h4><?php echo e($error); ?></h4></td></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <tr><td><h3>Description: </h3></td><td><textarea name="description" rows="4"><?php echo e(old('description')); ?></textarea></td></tr>
                    <?php if($errors->has('description')): ?>
                        <?php $__currentLoopData = $errors->get('description'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr><td></td><td><h4><?php echo e($error); ?></h4></td></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <tr><td><h3>Students Needed (in numbers): </h3></td><td><input type="number" name="students_needed" value="<?php echo e(old('students_needed')); ?>"></td></tr>
                    <?php if($errors->has('students_needed')): ?>
                        <?php $__currentLoopData = $errors->get('students_needed'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr><td></td><td><h4><?php echo e($error); ?></h4></td></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <tr><td><h3>Year: </h3></td><td><input type="number" name="year" value="<?php echo e(old('year')); ?>"></td></tr>
                    <?php if($errors->has('year')): ?>
                        <?php $__currentLoopData = $errors->get('year'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr><td></td><td><h4><?php echo e($error); ?></h4></td></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <tr><td><h3>Trimester: </h3></td><td><select name="trimester" value="<?php echo e(old('trimester')); ?>">
                        <option value=1>1</option>
                        <option value=2>2</option>
                        <option value=3>3</option>
                    </select></td></tr>
                    <?php if($errors->has('trimester')): ?>
                        <?php $__currentLoopData = $errors->get('trimester'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr><td></td><td><h4><?php echo e($error); ?></h4></td></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <tr><td colspan=2><input type="submit" value="Create">
                <table>
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/AssignmentTwo/blank/resources/views/wils/create.blade.php ENDPATH**/ ?>