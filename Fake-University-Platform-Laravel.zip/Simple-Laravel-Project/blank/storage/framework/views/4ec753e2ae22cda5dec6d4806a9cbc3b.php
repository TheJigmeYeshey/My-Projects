<?php $__env->startSection('page-content'); ?>
<section class="capsule">
            <div class="pill">
                    <h3 class="content-title"><?php echo e($post->P_Title); ?></h3>
                    <div class="content-shaper">
                                <h3> <?php echo e($post->P_Author); ?>  ||  <?php echo e($post->P_Date); ?></h3>
                                <p class="content-text">
                                    <?php echo e($post->P_Message); ?>

                                </p>
                                    <form method="post" action=" <?php echo e(url("like_post")); ?> ">
                                        <h3>Liked by: </h3>
                                        <?php echo e(csrf_field()); ?>

                                        <input type="text" name="author" value="<?php echo e($username); ?>">
                                        <input type="hidden" name="id" value="<?php echo e($post->PostID); ?>">
                                        <input type="submit" value="Like">
                                    </form>
                                    <div class="buttons">
                                        <form method="post" action=" <?php echo e(url("edit_post")); ?> ">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="id" value="<?php echo e($post->PostID); ?>">
                                            <input type="submit" value="Edit">
                                        </form>
                                        <form method="post" action=" <?php echo e(url("delete_post")); ?> ">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="id" value="<?php echo e($post->PostID); ?>">
                                            <input type="submit" value="Delete">
                                        </form>
                                    </div>
                                <div class="content-shaper">
                                    <h3>Comments:</h3>
                                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="content-shaper">
                                                <div class="content-bg" class>
                                                    <div class="title-date">
                                                        <div>
                                                            <p><?php echo e($comment->C_Author); ?>: <?php echo e($comment->C_Message); ?></p>
                                                            <h6><?php echo e($comment->C_Date); ?></h6>
                                                        </div>
                                                        <form method="post" action="<?php echo e(url("comment_comment")); ?> ">
                                                            <?php echo e(csrf_field()); ?>

                                                            <input type="hidden" name="commentID" value="<?php echo e($comment->CommentID); ?>">
                                                            <input type="hidden" name="postID" value="<?php echo e($post->PostID); ?>">
                                                            <input type="hidden" name="user" value="<?php echo e($comment->C_Author); ?>">
                                                            <input type="submit" value="Reply">
                                                        </form>
                                                    </div>
                                                </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <h3>Add Comment: </h3>
                                    <form method="post" action=" <?php echo e(url("adding_comment")); ?> ">
                                        <?php echo e(csrf_field()); ?>

                                        <table>
                                            <tr><td><h3>Author: </h3></td><td><input type="text" name="user" value="<?php echo e($username); ?>"></td></tr>
                                            <tr><td><h3>Message: </h3></td><td><textarea name="comment" rows="4"></textarea></td></tr>
                                            <input type="hidden" name="id" value="<?php echo e($post->PostID); ?>">
                                            <tr><td colspan=2><input type="submit" value="Submit">
                                        <table>
                                    </form>
                                </div>
                    </div>
            </div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Assignment/blank/resources/views/details.blade.php ENDPATH**/ ?>