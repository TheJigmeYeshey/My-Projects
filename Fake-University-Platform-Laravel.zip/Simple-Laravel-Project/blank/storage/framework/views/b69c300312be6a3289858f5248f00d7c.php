<?php $__env->startSection('page-content'); ?>
<section class="capsule">
            <div class="pill">
                    <h3 class="content-title"><?php echo e($project->title); ?>  ||  Industry Partner: <?php echo e($provider->name); ?></h3>
                    <div class="content-shaper">
                                <?php if($project->image != null): ?>
                                    <img src="<?php echo e(url($project->image)); ?>" alt="project image" style="width:300px;height:300px;">
                                <?php endif; ?>
                                <h3> Description </h3>
                                <p class="content-text">
                                    <?php echo e($project->description); ?><br>
                                </p>
                                <p class="content-text">
                                    Students needed: <?php echo e($project->students_needed); ?>

                                </p>
                                <?php if($project->pdf != null): ?>
                                    <a href="<?php echo e(url($project->pdf)); ?>" download>Download PDF for more information.</a>
                                <?php endif; ?>
                                <br>
                                <br>
                                <form method="post" action=' <?php echo e(url("teacher/$project->id")); ?> '>
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('PUT')); ?>

                                        <table>
                                            <tr><td colspan=2><input type="submit" value="Approve">
                                        <table>
                                </form>
                    </div>
            </div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/AssignmentTwo/blank/resources/views/wils/project_approval.blade.php ENDPATH**/ ?>