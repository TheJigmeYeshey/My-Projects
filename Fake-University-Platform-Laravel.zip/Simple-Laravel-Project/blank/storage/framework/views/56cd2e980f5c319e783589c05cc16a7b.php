<?php $__env->startSection('page-content'); ?>
    <section class="capsule">
            <div class="pill">
                <h3 class="content-title">Students</h3>
                    <ol>
                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <div class="title-date">
                                        <h2><a href="student/<?php echo e($student->id); ?>"><?php echo e($student->name); ?></a></h2>
                                    </div>
                                </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>
            </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/AssignmentTwo/blank/resources/views/wils/students_list.blade.php ENDPATH**/ ?>