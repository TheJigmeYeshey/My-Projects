<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elmore</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap">

</head>
<body>
    <header>
        <div class="container">
            <h1>El<span id="more">more</span></h1>
            <nav>
                <a href="<?php echo e(url('/')); ?>" class="nav-text">Home</a>
                <a href="<?php echo e(url('/users')); ?>" class="nav-text">Users</a>
            </nav>
        </div>
    </header>
    <main>
        <?php echo $__env->yieldContent('page-content'); ?>
    </main>
    <footer>
        <div id='copyright'>
            <p>&copy; Jigme Yeshey | Assignment 1</p>
        </div>
    </footer>
</body>
</html><?php /**PATH /var/www/html/Assignment/blank/resources/views/layouts/default.blade.php ENDPATH**/ ?>