-- Create table called posts
create table if not exists posts (    
    PostID integer not null primary key autoincrement,    
    P_Title varchar(80) not null,
    P_Author varchar(80) not null,    
    P_Message text default '',
    P_Date DATE not null
); 

-- Create table called comments
create table if not exists comments (    
    CommentID integer not null primary key autoincrement,    
    C_Author varchar(80) not null,    
    C_Message text default '',
    C_Date date not null,
    PostID integer not null references posts(PostID)
); 

-- Create table called likes
create table if not exists likes (
    LikeID integer not null primary key autoincrement,
    L_Author varchar(80) not null,    
    PostID integer not null references posts(PostID)
);

-- Create table called association
create table if not exists association (
    AssID integer not null primary key autoincrement,
    ID_1 integer not null references comments(CommentID),
    ID_2 integer not null references comments(CommentID)
);

-- Insert data into the posts table
INSERT INTO posts (P_Title, P_Author, P_Message, P_Date) VALUES
    ("Celebrities should not have freedom of speech", "Sum Ting Wong", "The problem of this issue pertains to the fans and not the celebrities.", '2023-08-03 00:00:00'),
    ("Biomimicry, an expensive disaster", "Dami Lee", "Buildings that copy nature is very costly and ineffective. Humans are not capable of carrying out projects like these at the moment.", '2023-07-12 00:00:00'),
    ("Brutalism, Art or Ugly?", "Sum Ting Wong", "The general population dislikes concrete. Architects, however, seem to love the raw look and texture of it.", '2023-08-27 00:00:00');

-- Insert comments for the first post
INSERT INTO comments (C_Author, C_Message, C_Date, PostID) VALUES
    ('Alice', 'I agree with the author.', '2023-08-04 08:30:00', 1),
    ('Bob', 'I disagree, celebrities should have freedom of speech.', '2023-08-05 10:15:00', 1),
    ('Charlie', 'Interesting discussion!', '2023-08-05 14:45:00', 1);

-- Insert comments for the second post
INSERT INTO comments (C_Author, C_Message, C_Date, PostID) VALUES
    ('Eve', 'I think biomimicry is the future.', '2023-07-15 09:20:00', 2),
    ('Frank', 'I have seen some amazing biomimicry designs.', '2023-07-15 11:55:00', 2);

-- Insert comments for the third post
INSERT INTO comments (C_Author, C_Message, C_Date, PostID) VALUES
    ('Alice', 'I appreciate the aesthetics of brutalism.', '2023-08-29 16:10:00', 3),
    ('Dave', 'Brutalism is an acquired taste.', '2023-08-29 18:45:00', 3);


-- Insert likes for posts with names
INSERT INTO likes (L_Author, PostID) VALUES
    ('John Doe', 1),
    ('Alice Smith', 1),
    ('Bob Johnson', 2),
    ('Emily Davis', 3), 
    ('Michael Wilson', 3); 

-- Insert values into the association table
INSERT INTO association (ID_1, ID_2) VALUES
    (1, 2),
    (4, 5),
    (4, 8);