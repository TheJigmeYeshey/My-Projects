<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProfilesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('profiles')->insert([
            'GPA' => 6,
            'software_developer' => true,
            'project_manager' => true,
            'business_analyst' => false,
            'tester' => false,
            'client_liaison' => false,
            'user_id' => 1,
        ]);

        DB::table('profiles')->insert([
            'GPA' => 5,
            'software_developer' => true,
            'project_manager' => true,
            'business_analyst' => true,
            'tester' => false,
            'client_liaison' => false,
            'user_id' => 5,
        ]);

        DB::table('profiles')->insert([
            'GPA' => 6,
            'software_developer' => false,
            'project_manager' => true,
            'business_analyst' => false,
            'tester' => false,
            'client_liaison' => false,
            'user_id' => 6,
        ]);

        DB::table('profiles')->insert([
            'GPA' => 6,
            'software_developer' => true,
            'project_manager' => true,
            'business_analyst' => false,
            'tester' => false,
            'client_liaison' => true,
            'user_id' => 7,
        ]);

        DB::table('profiles')->insert([
            'GPA' => 6,
            'software_developer' => true,
            'project_manager' => true,
            'business_analyst' => true,
            'tester' => false,
            'client_liaison' => false,
            'user_id' => 8,
        ]);

        DB::table('profiles')->insert([
            'GPA' => 4,
            'software_developer' => true,
            'project_manager' => false,
            'business_analyst' => true,
            'tester' => false,
            'client_liaison' => false,
            'user_id' => 14,
        ]);

        DB::table('profiles')->insert([
            'GPA' => 5,
            'software_developer' => true,
            'project_manager' => true,
            'business_analyst' => true,
            'tester' => true,
            'client_liaison' => false,
            'user_id' => 15,
        ]);

        DB::table('profiles')->insert([
            'GPA' => 6,
            'software_developer' => true,
            'project_manager' => false,
            'business_analyst' => false,
            'tester' => false,
            'client_liaison' => false,
            'user_id' => 16,
        ]);

        DB::table('profiles')->insert([
            'GPA' => 7,
            'software_developer' => true,
            'project_manager' => false,
            'business_analyst' => true,
            'tester' => false,
            'client_liaison' => false,
            'user_id' => 17,
        ]);

        DB::table('profiles')->insert([
            'GPA' => 2,
            'software_developer' => true,
            'project_manager' => true,
            'business_analyst' => true,
            'tester' => false,
            'client_liaison' => true,
            'user_id' => 18,
        ]);
        //
    }
}
