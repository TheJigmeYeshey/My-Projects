<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProjectsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('projects')->insert([
            'title' => 'Hologram Concert',
            'description' => 'We plan on creating an Australian version of vocaloid.',
            'students_needed' => 5,
            'year' => 2024,
            'trimester' => 1,
            'user_id' => 2,
            'image' => 'test_image/test.jpg',
            'pdf' => 'dummy_pdf/dummy.pdf',
            'updated_at' => DB::raw('CURRENT_TIMESTAMP'),
        ]);

        DB::table('projects')->insert([
            'title' => 'Sensory Inducing Headset',
            'description' => 'We will be using brain-inducing frequency to induce sensories with our headset.',
            'students_needed' => 3,
            'year' => 2025,
            'trimester' => 2,
            'user_id' => 3,
            'updated_at' => DB::raw('CURRENT_TIMESTAMP'),
        ]);

        DB::table('projects')->insert([
            'title' => 'Artificial Meat Production',
            'description' => 'We plan on creating high-protein meals from carbon.',
            'students_needed' => 6,
            'year' => 2024,
            'trimester' => 1,
            'user_id' => 4,
            'image' => 'test_image/test.jpg',
            'pdf' => 'dummy_pdf/dummy.pdf',
            'updated_at' => DB::raw('CURRENT_TIMESTAMP'),
        ]);

        DB::table('projects')->insert([
            'title' => 'Construction Drone',
            'description' => 'We will hold a short introductory on how to build drones for construction.',
            'students_needed' => 4,
            'year' => 2026,
            'trimester' => 3,
            'user_id' => 9,
            'image' => 'test_image/test.jpg',
            'pdf' => 'dummy_pdf/dummy.pdf',
            'updated_at' => DB::raw('CURRENT_TIMESTAMP'),
        ]);

        DB::table('projects')->insert([
            'title' => 'Diabetes Analysis',
            'description' => 'You will be working with health professionals to create a data analysis tool.',
            'students_needed' => 3,
            'year' => 2026,
            'trimester' => 2,
            'user_id' => 10,
            'image' => 'test_image/test.jpg',
            'pdf' => 'dummy_pdf/dummy.pdf',
            'updated_at' => DB::raw('CURRENT_TIMESTAMP'),
        ]);
        //
    }
}
