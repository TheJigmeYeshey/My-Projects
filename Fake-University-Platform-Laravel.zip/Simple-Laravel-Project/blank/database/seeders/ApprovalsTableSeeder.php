<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ApprovalsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('approvals')->insert([
            'status' => "approved",
            'project_id' => 1,
        ]); 
        DB::table('approvals')->insert([
            'status' => "approved",
            'project_id' => 2,
        ]);
        DB::table('approvals')->insert([
            'status' => "approved",
            'project_id' => 3,
        ]);  
        DB::table('approvals')->insert([
            'status' => "approved",
            'project_id' => 4,
        ]);  
        DB::table('approvals')->insert([
            'status' => "approved",
            'project_id' => 5,
        ]);  
        //
    }
}
