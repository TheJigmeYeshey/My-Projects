<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('users')->insert([
            'name' => 'David',
            'type' => 'Student',
            'email' => 'david@gmail.com',
            'password' => bcrypt('12345678'),
        ]);
        DB::table('users')->insert([
            'name' => 'Pineapple',
            'type' => 'Industry Partner',
            'email' => 'pineapple@gmail.com',
            'password' => bcrypt('12345678'),
        ]);
        DB::table('users')->insert([
            'name' => 'Blueberry',
            'type' => 'Industry Partner',
            'email' => 'blueberry@gmail.com',
            'password' => bcrypt('12345678'),
        ]);
        DB::table('users')->insert([
            'name' => 'cranberry',
            'type' => 'Industry Partner',
            'email' => 'cranberry@gmail.com',
            'password' => bcrypt('12345678'),
        ]);
        DB::table('users')->insert([
            'name' => 'Jack',
            'type' => 'Student',
            'email' => 'jack@gmail.com',
            'password' => bcrypt('12345678'),
        ]);
        DB::table('users')->insert([
            'name' => 'Miles',
            'type' => 'Student',
            'email' => 'miles@gmail.com',
            'password' => bcrypt('12345678'),
        ]);
        DB::table('users')->insert([
            'name' => 'Vy',
            'type' => 'Student',
            'email' => 'vy@gmail.com',
            'password' => bcrypt('12345678'),
        ]);
        DB::table('users')->insert([
            'name' => 'Mika',
            'type' => 'Student',
            'email' => 'mika@gmail.com',
            'password' => bcrypt('12345678'),
        ]);
        DB::table('users')->insert([
            'name' => 'Dragonfruit',
            'type' => 'Industry Partner',
            'email' => 'dragonfruit@gmail.com',
            'password' => bcrypt('12345678'),
        ]);
        DB::table('users')->insert([
            'name' => 'Banana',
            'type' => 'Industry Partner',
            'email' => 'banana@gmail.com',
            'password' => bcrypt('12345678'),
        ]);
        DB::table('users')->insert([
            'name' => 'Tomato',
            'type' => 'Industry Partner',
            'email' => 'tomato@gmail.com',
            'password' => bcrypt('12345678'),
        ]);
        DB::table('users')->insert([
            'name' => 'Avocado',
            'type' => 'Industry Partner',
            'email' => 'avocado@gmail.com',
            'password' => bcrypt('12345678'),
        ]);
        DB::table('users')->insert([
            'name' => 'Beth',
            'type' => 'Teacher',
            'email' => 'beth@gmail.com',
            'password' => bcrypt('12345678'),
        ]);
        DB::table('users')->insert([
            'name' => 'Alex',
            'type' => 'Student',
            'email' => 'alex@gmail.com',
            'password' => bcrypt('12345678'),
        ]);
        DB::table('users')->insert([
            'name' => 'Wu',
            'type' => 'Student',
            'email' => 'wu@gmail.com',
            'password' => bcrypt('12345678'),
        ]);
        DB::table('users')->insert([
            'name' => 'Honey',
            'type' => 'Student',
            'email' => 'honey@gmail.com',
            'password' => bcrypt('12345678'),
        ]);
        DB::table('users')->insert([
            'name' => 'Milan',
            'type' => 'Student',
            'email' => 'milan@gmail.com',
            'password' => bcrypt('12345678'),
        ]);
        DB::table('users')->insert([
            'name' => 'Chicago',
            'type' => 'Student',
            'email' => 'chicago@gmail.com',
            'password' => bcrypt('12345678'),
        ]);
        //
    }
}
