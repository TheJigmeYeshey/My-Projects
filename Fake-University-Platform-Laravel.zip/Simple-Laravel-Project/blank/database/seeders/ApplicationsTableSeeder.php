<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ApplicationsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('applications')->insert([
            'user_id' => 5,
            'project_id' => 2,
            'justification' => 'The idea seems farfetching but I am curious of how far we could go with this project.',
            'approved' => 'no',
        ]);
        DB::table('applications')->insert([
            'user_id' => 1,
            'project_id' => 3,
            'justification' => "I want to join this. It looks fun.",
            'approved' => 'no',
        ]);
        DB::table('applications')->insert([
            'user_id' => 6,
            'project_id' => 4,
            'justification' => 'I hope I can be approved for this project.',
            'approved' => 'no',
        ]);
        DB::table('applications')->insert([
            'user_id' => 7,
            'project_id' => 1,
            'justification' => 'I love how technology is advancing so fast. We can do these things now.',
            'approved' => 'no',
        ]);
        DB::table('applications')->insert([
            'user_id' => 8,
            'project_id' => 2,
            'justification' => 'This might be the future.',
            'approved' => 'no',
        ]);
        DB::table('applications')->insert([
            'user_id' => 14,
            'project_id' => 5,
            'justification' => 'This sounds controversial but I like the idea.',
            'approved' => 'no',
        ]);
        DB::table('applications')->insert([
            'user_id' => 15,
            'project_id' => 2,
            'justification' => 'I hope this project becomes a success.',
            'approved' => 'no',
        ]);
        DB::table('applications')->insert([
            'user_id' => 16,
            'project_id' => 2,
            'justification' => 'I hope I can take part in this amazing project.',
            'approved' => 'no',
        ]);
        DB::table('applications')->insert([
            'user_id' => 17,
            'project_id' => 3,
            'justification' => 'To be honest, all the projects look farfetching but this one is at least realistic.',
            'approved' => 'no',
        ]);
        //
    }
}
